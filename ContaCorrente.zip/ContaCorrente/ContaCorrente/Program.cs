﻿using System;

namespace ContaCorrente
{
    class Program
    {
        static void Main(string[] args)
        {
            contaCorrente conta1 = new contaCorrente();
            conta1.titular = "Jéssica";
            conta1.agencia = 1101;
            conta1.nConta = 223344;
            conta1.saldo = 200.00;

            Console.WriteLine("Olá " + conta1.titular);
            Console.WriteLine("Esses são os dados da sua nova conta: ");
            Console.WriteLine("agencia:"+ conta1.agencia+" Conta:"+conta1.nConta);
            Console.ReadLine();
        }
    }
}
