﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa
{
    class Terceiro : funcionario
    {
               
        public double CalculaSalario()
        {
            return salario = cargaHoraria * valorHora * taxaServiço;
        }

        public  void ImprimeDados()
        {
            Console.WriteLine("Funcionario:" + nome);
            Console.WriteLine("Empresa:" + empresaOrigem);
            Console.WriteLine("Salario R$:" + Convert.ToInt32(salario) + ",00");
        }
    }
}
