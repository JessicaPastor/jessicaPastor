﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa
{
    public class funcionario 
    {
        public double salario;        
        public string nome { get; set; }
        public int cargaHoraria { get; set; }
        public double valorHora { get; set; }        
        public string empresaOrigem { get; set; }

        public double taxaServiço = 1.15;

        public double CalculaSalario()
        {
            return salario = cargaHoraria * valorHora;
        }

        
        public void ImprimeDados()
        {
            Console.WriteLine("Funcionario: " + nome);            
            Console.WriteLine("Salario R$:" + salario,2f );
        }
    }
}
