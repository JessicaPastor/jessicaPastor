﻿using System;

namespace Empresa
{
    class Program
    {
        static void Main(string[] args)
        {
            string tipoFuncionario;

            Console.WriteLine("\r\n Você é terceirizado?\r\n 1 - Sim \r\n 2 - Não\r\n");
            tipoFuncionario = (Console.ReadLine());

            if(tipoFuncionario == "1")
            {
                Terceiro Ana = new Terceiro();
                Ana.nome = "Ana";
                Ana.empresaOrigem = "One";
                Ana.valorHora = 20;
                Ana.cargaHoraria = 170;                
                Ana.CalculaSalario();
                Ana.ImprimeDados(); 
                
            }

            else
            {
                funcionario joao = new funcionario();
                joao.nome = "João";
                joao.valorHora = 20;
                joao.cargaHoraria = 170;
                joao.CalculaSalario();
                joao.ImprimeDados();
            }

            Console.ReadLine();
            
        }
    }
}
